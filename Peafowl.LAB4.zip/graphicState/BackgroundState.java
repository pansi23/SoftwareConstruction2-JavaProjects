package graphicState;

import java.awt.Color;
import java.awt.Graphics;
import drawingTool.Scene;

public class BackgroundState extends State {
	private static BackgroundState instance;
	
    private  BackgroundState(Scene scene) {
        this.context = scene;
        background = this;
    }
    
    public static BackgroundState getInstance(Scene context) {
    	if (instance == null) {
    		instance = new BackgroundState(context);
    	}
    	
    	return instance;
    }


	@Override
	public State changeBackground() {
		context.changeBackground(null, null);
		return this;
	}

	@Override
	public State villageState() {
		context.setVillage();
		return villageState.getInstance(context);
	}

	@Override
	public State drawNormalState() {
		context.drawAll();
		return normalState.getInstance(context);
	}
}
