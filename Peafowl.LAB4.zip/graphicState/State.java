package graphicState;

import drawingTool.Scene;

public abstract class State {
	protected Scene context;
	
	protected static BackgroundState background;
	protected static villageState village;
	protected static normalState normal;
	
	public abstract State changeBackground();
	public abstract State villageState();
	public abstract State drawNormalState();
}