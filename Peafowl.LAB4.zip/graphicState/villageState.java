package graphicState;

import drawingTool.Scene;

public class villageState extends State{
	private static villageState instance;
	
	private villageState(Scene context) {
		this.context = context;
		village = this;
	}
	
	public static villageState getInstance(Scene context) {
		if (instance == null) {
			instance = new villageState(context);
		}
		return instance;
	}
	
	@Override
	public State changeBackground() {
		context.changeBackground(null, null);
		return BackgroundState.getInstance(context);
	}

	@Override
	public State villageState() {
		context.setVillage();
		return this;
	}

	@Override
	public State drawNormalState() {
		context.drawAll();
		return normalState.getInstance(context);
	}

}
