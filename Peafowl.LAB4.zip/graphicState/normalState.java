package graphicState;

import java.awt.Graphics;

import drawingTool.Peafowl;
import drawingTool.Scene;

public class normalState extends State {
	private static normalState instance;

	private normalState(Scene context) {
		this.context = context;
		normal = this;
	}

	public static normalState getInstance(Scene context) {
		if (instance == null) {
			instance = new normalState(context);
		}
		return instance;
	}
/*
	@Override
    public void draw(Graphics pen) {
        for (Peafowl fowl : scene.getFowls()) {
            fowl.draw();
        }
    }
*/
	@Override
	public State changeBackground() {
		context.changeBackground(null, null);
		return BackgroundState.getInstance(context);
	}

	@Override
	public State villageState() {
		context.setVillage();
		return villageState.getInstance(context);
	}

	@Override
	public State drawNormalState() {
		context.drawAll();
		return this;
	}

}
