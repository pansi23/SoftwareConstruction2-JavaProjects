package drawingTool;

import java.awt.Color;

public class Tarsus extends BodyParts {
    public Tarsus(int x, int y) {
    	super(x, y, 15, 20, Color.gray );
    	}
    public void drawAt(int left, int bottom) {
        Drawing.pen().setColor(Color.DARK_GRAY);
        Drawing.pen().drawLine(left, bottom, left-width/3, bottom + height); // Drawing left
        Drawing.pen().drawLine(left, bottom, left+width/3, bottom + height);
        Drawing.pen().drawLine(left, bottom, left, bottom + height);
        
        Drawing.pen().drawLine(left+width, bottom, left+width-width/3 , bottom+ height); // Drawing right
        Drawing.pen().drawLine(left+width, bottom,left+width+width/3, bottom+ height);
        Drawing.pen().drawLine(left+width, bottom, left+width, bottom+ height);
    }

    
    
    @Override
    public void draw() {
        drawAt(address.x, address.y);
    }
        
}
