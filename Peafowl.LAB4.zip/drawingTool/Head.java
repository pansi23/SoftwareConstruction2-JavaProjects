package drawingTool;

import java.awt.Color;

public class Head extends BodyParts {
	private Beak beak; // composite
	private Eye eye; // composite
	private Crest crest; // composite

	public Head(int x, int y) {
		super(x, y, 50, 50, Color.blue);
		beak = new Beak(x, y);
		eye = new Eye(x, y);
		crest = new Crest(x, y);
	}

	public void drawAt(int left, int bottom) {
		Drawing.pen().setColor(Color.blue/* colour */);
		Drawing.pen().fillOval(left, bottom, width, height );
		beak.drawAt(left, bottom);
		eye.drawAt(left, bottom);
		crest.drawAt(left, bottom);
	}

	@Override
	public void draw() {
		drawAt(address.x, address.y);
	}
}
