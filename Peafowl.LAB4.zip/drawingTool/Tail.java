package drawingTool;

import java.awt.Color;

public class Tail extends BodyParts {
	public Tail(int x, int y) {
		super(x, y, 240, 50, Color.cyan);
	}
	
	public void drawAt(int left, int bottom) {
        
        int[] xPoints = {left, left + width, left + width};
        int[] yPoints = {bottom-height, bottom , bottom-height};
        int nPoints = 3;
        Drawing.pen().setColor(color);
        Drawing.pen().fillPolygon(xPoints, yPoints, nPoints);
        
    }

    @Override
    public void draw() {
        drawAt(address.x, address.y);
    }

}
