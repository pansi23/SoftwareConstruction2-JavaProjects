package drawingTool;

import java.awt.Color;

public class Crest  extends BodyParts {
	public Crest(int x, int y) {
		super(x, y, 10, 20 , Color.black);
    }
	
    public void drawAt( int left, int bottom) {

	Drawing.pen().setColor(Color.blue);
    Drawing.pen().drawLine(left+width, bottom-height, left+2*width, bottom+height/4);
    Drawing.pen().drawLine(left+2*width, bottom-height, left+2*width, bottom+height/4);
    Drawing.pen().drawLine(left+3*width, bottom-height, left+2*width, bottom+height/4);
 
    }
    @Override
    public void draw() {
        drawAt(address.x, address.y);
    }


}
