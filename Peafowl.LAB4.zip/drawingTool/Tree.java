package drawingTool;

import java.awt.Color;
import java.awt.Graphics;

public class Tree {
    private int x, y, width, height;
    private Color color;

    public Tree(int x, int y, int width, int height) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.color = new Color(34, 139, 34); // Default green colour for trees
    }

    public void setColor(Color color) {
        this.color = color;
    }

    public void setSize(int width, int height) {
        this.width = width;
        this.height = height;
    }

    public void draw() {
        // Draw the trunk
    	Drawing.pen().setColor(new Color(139, 69, 19)); // Brown colour for trunk
    	Drawing.pen().fillRect(x + width / 4, y + height / 2, width / 2, height / 2);

        // Draw the leaves
    	Drawing.pen().setColor(color);
    	Drawing.pen().fillOval(x, y, width, height / 2);
    }
}
