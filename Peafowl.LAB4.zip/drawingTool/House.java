package drawingTool;

import java.awt.Color;
import java.awt.Graphics;

public class House {
    private int x, y, width, height;
    private Color color;

    public House(int x, int y, int width, int height) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.color = Color.RED; // Default red color for houses
    }

    public void setColor(Color color) {
        this.color = color;
    }

    public void setSize(int width, int height) {
        this.width = width;
        this.height = height;
    }

    public void draw() {
        // Draw the main body of the house
        Drawing.pen().setColor(color);
        Drawing.pen().fillRect(x, y, width, height);

        // Draw the roof
        Drawing.pen().setColor(Color.DARK_GRAY);
        int[] xPoints = {x, x + width / 2, x + width};
        int[] yPoints = {y, y - height / 2, y};
        Drawing.pen().fillPolygon(xPoints, yPoints, 3);
    }
}

