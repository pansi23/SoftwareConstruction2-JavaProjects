package drawingTool;

import java.awt.Color;
import java.awt.Graphics;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import javax.swing.JFrame;

import graphicState.*;

public class Scene {
    private ArrayList<Peafowl> fowls = null;
    private ArrayList<House> houses = null;
    private ArrayList<Tree> trees = null;
    private Color background;
    private static State graphicState;

    public Scene() {
        fowls = new ArrayList<Peafowl>();
        houses = new ArrayList<House>();
        trees = new ArrayList<Tree>();
        generateScene();
        graphicState = normalState.getInstance(this); // Initialise with a concrete state
    }

    public void generateBackground() {
        background = new Color(0, RandomNumber.getRandomNumber(128, 255), 0);
    }

    public void generateScene() {
       // generateBackground();
        //fowls.clear();
        //houses.clear();
        //trees.clear();

        int numberOfPeafowls = RandomNumber.getRandomNumber(1, 10);
        for (int i = 0; i < numberOfPeafowls; i++) {
            addSomeNewPeafowl();
        }

       // setHouses();
        //setTrees();
    }

    private void addSomeNewPeafowl() {
        boolean positionFound = false;
        int x = 0, y = 0, width = 0, height = 0;
        Color color = null;
        while (!positionFound) {
            x = RandomNumber.getRandomNumber(50, 600);
            y = RandomNumber.getRandomNumber(50, 400);
            width = RandomNumber.getRandomNumber(100, 200);
            height = RandomNumber.getRandomNumber(140, 300);
            color = generateRandomColor();

            Peafowl newPeafowl = new Peafowl(x, y, width, height, color);
            if (!isOverlapping(newPeafowl)) {
                positionFound = true;
                fowls.add(newPeafowl);
            }
        }
    }

    private boolean isOverlapping(Peafowl newPeafowl) {
        for (Peafowl fowl : fowls) {
            if (fowl.intersects(newPeafowl)) {
                return true;
            }
        }
        return false;
    }

    private void addSomeNewHouse() {
        int x = RandomNumber.getRandomNumber(50, 600);
        int y = RandomNumber.getRandomNumber(50, 400);
        int width = RandomNumber.getRandomNumber(50, 100);
        int height = RandomNumber.getRandomNumber(50, 100);
        houses.add(new House(x, y, width, height));
    }

    private void addSomeNewTree() {
        int x = RandomNumber.getRandomNumber(50, 600);
        int y = RandomNumber.getRandomNumber(50, 400);
        int width = RandomNumber.getRandomNumber(20, 40);
        int height = RandomNumber.getRandomNumber(50, 100);
        trees.add(new Tree(x, y, width, height));
    }

    public void drawAll() {
       // Drawing.set(pen);  // Ensure Drawing.pen() is set
        // Draw background
        //pen.setColor(background);
       // pen.fillRect(0, 0, 2000, 2000);

        // Draw fowls, houses, and trees
        for (Peafowl fowl : fowls) {
            fowl.draw();
        }
        for (House house : houses) {
            house.draw();
        }
        for (Tree tree : trees) {
            tree.draw();
        }
    }


    public Color getBackground() {
        return background;
    }

    public ArrayList<Peafowl> getFowls() {
        return fowls;
    }

    public void setColor(Color color) {
        for (Peafowl fowl : fowls) {
            fowl.setColor(color);
        }
    }

    public void setColors(List<Color> colors) {
        int size = Math.min(colors.size(), fowls.size());
        for (int i = 0; i < size; i++) {
            fowls.get(i).setColor(colors.get(i));
        }
    }

    public void setSize(int width, int height) {
        for (Peafowl fowl : fowls) {
            fowl.setSize(width, height);
        }
    }

    public void setHouses() {
        houses.clear();
        int numberOfHouses = RandomNumber.getRandomNumber(1, 5);
        for (int i = 0; i < numberOfHouses; i++) {
            addSomeNewHouse();
        }
    }

    public void setTrees() {
        trees.clear();
        int numberOfTrees = RandomNumber.getRandomNumber(1, 5);
        for (int i = 0; i < numberOfTrees; i++) {
            addSomeNewTree();
        }
    }

    public void setVillage() {
        setHouses();
        setTrees();
    }

    public void changeColors() {
        for (Peafowl fowl : fowls) {
            Color newColor = generateRandomColor();
            fowl.setColor(newColor);
        }
    }

    private Color generateRandomColor() {
        return new Color(RandomNumber.getRandomNumber(0, 255),
                         RandomNumber.getRandomNumber(0, 255),
                         RandomNumber.getRandomNumber(0, 255));
    }

	public void changeBackground(JFrame frame, DrawingArea drawing) {
		frame.getContentPane().setBackground(generateRandomColor());
		drawing.setOpaque(false);
		drawing.revalidate();
		drawing.repaint();
	}
	
	public void setVillageState() {
		graphicState = graphicState.villageState();
	}
	
	public void setNormalState() {
		graphicState = graphicState.drawNormalState();
	}
	
	public void setBackgroundState() {
		graphicState = graphicState.changeBackground();
	}

	
}
