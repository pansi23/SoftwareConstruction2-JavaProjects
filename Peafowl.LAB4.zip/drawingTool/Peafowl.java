package drawingTool;

import java.awt.Color;
import java.awt.Point;

public class Peafowl implements LocatedRectangle {
	private Point address;
	private int width;
	private int height;
	private Head head;
	private Body body;
	
	public Peafowl(int x, int y, int width, int height, Color color) {
		this.address = new Point(x, y);
		this.width = width;
		this.height = width*3/2;

		int headX = x + width / 5;
		int headY = y - height/2;
		
		int bodyX = x;
		int bodyY = y;

		head = new Head(headX, headY);
		body = new Body(bodyX, bodyY);

	}

	public void setColor(Color color) {
		head.setColor(color);
		body.setColor(color);
	
	}

	public void setSize(int width, int height) {
		this.width = width;
		this.height = height;
		head.setSize(width, height);
		body.setSize(width, height);

	}

	@Override
	public Point address() {
		return address;
	}

	@Override
	public int width() {
		return width;
	}

	@Override
	public int height() {
		return height;
	}

	@Override
	public void draw() {
		body.draw();
		head.draw();
		;

	} 

}
