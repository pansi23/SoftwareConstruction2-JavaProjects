package drawingTool;

import javax.swing.JPanel;
import java.awt.Graphics;

public class DrawingArea extends JPanel {
    private static final long serialVersionUID = 1L;
    private Scene scene;

    public DrawingArea() {
        scene = new Scene();
    }

    public Scene getScene() {
        return scene;
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Drawing.set(g);
        scene.drawAll();
    }
}
