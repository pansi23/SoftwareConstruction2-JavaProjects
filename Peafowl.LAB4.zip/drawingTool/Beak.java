package drawingTool;

import java.awt.Color;

public class Beak extends BodyParts{
	public Beak(int x, int y) {
		super(x, y, 20, 10, Color.ORANGE);
	}
	
	

    public void drawAt(int left, int bottom) {
    	Drawing.pen().setColor(Color.orange);
        int[] xPoints = {left-width, left+width/20 , left +width/20};
        int[] yPoints = {bottom+2*height, bottom+3*height, bottom+2*height};
        int nPoints = 3;
        Drawing.pen().fillPolygon(xPoints, yPoints, nPoints);
    }
    @Override
    public void draw() {
    	drawAt(address.x, address.y);
    }

}
 