package drawingTool;

import java.awt.Color;
import java.awt.Point;

public abstract class BodyParts {
	protected int width;
	protected int height;
	protected Color color;
	protected Point address;

	public BodyParts(int x, int y, int width, int height, Color color) {
		this.address = new Point(x, y);
		this.width = width;
		this.height = height;
		this.color = color;
	}

	public void setColor(Color color) {
		this.color = color;
	}

	public void setSize(int width, int height) {
		this.width = width;
		this.height = height;
	}

	public Point address() {
		return address;
	}

	public int width() {
		return width;
	}

	public int height() {
		return height;
	}

	public abstract void draw();

}
