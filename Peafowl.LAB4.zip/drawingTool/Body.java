package drawingTool;

import java.awt.Color;

public class Body extends BodyParts {
	private Neck neck;
	private Feathers feathers;
	private Tail tail;
	private Tarsus tarsus;
	private Legs legs;

	public Body(int x, int y) {
		super(x, y, 220, 90, Color.blue);
		neck = new Neck(x , y);
		feathers = new Feathers(x, y);
		tail = new Tail(x , y);
		tarsus = new Tarsus(x, y);
		legs = new Legs(x , y);
		
	}

	public void drawAt(int left, int bottom) {
		Drawing.pen().setColor(Color.blue);
		Drawing.pen().fillOval(left, bottom, width, height);
		neck.drawAt(left+width/4, bottom-height);
		feathers.drawAt(left+width/4, bottom+height/7);
		tail.drawAt(left+width, bottom+height);
		tarsus.drawAt(left+width/2, bottom+3*height/2);
		legs.drawAt(left+width/2, bottom+height);
		
		tail.setColor(color);
		
	}

	@Override
	public void draw() {
		drawAt(address.x, address.y);
	}

}
