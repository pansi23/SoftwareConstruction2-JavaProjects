package drawingTool;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.event.ChangeListener;

public class Buttons {
    private JButton colorButton = new JButton("Change Color");
    private JButton sizeButton = new JButton("Change Size");
    private JButton housesButton = new JButton("Houses");
    private JButton treesButton = new JButton("Trees");
    private JButton villageButton = new JButton("Village");
    private JButton backgroundButton = new JButton("Background");
    private JSlider sizeSlider = new JSlider(JSlider.HORIZONTAL, 50, 200, 100);
    private JLabel sizeLabel = new JLabel("Size:");
    private JButton exitButton = new JButton("Exit");

    public void addActionListener(ActionListener listener) {
        colorButton.addActionListener(listener);
        sizeButton.addActionListener(listener);
        housesButton.addActionListener(listener);
        treesButton.addActionListener(listener);
        villageButton.addActionListener(listener);
        exitButton.addActionListener(listener);
        backgroundButton.addActionListener(listener);
    }

    public void addChangeListener(ChangeListener listener) {
        sizeSlider.addChangeListener(listener);
    }

    public void addButtonsToAPanel(JFrame frame) {
        JPanel menu = new JPanel();
        menu.setLayout(new GridLayout(18, 1, 15, 20));

        menu.add(colorButton);
        menu.add(sizeLabel);
        menu.add(sizeSlider);
        menu.add(sizeButton);
        //menu.add(housesButton);
        //menu.add(treesButton);
        menu.add(villageButton);
        menu.add(backgroundButton);
        menu.add(exitButton);

        menu.setBorder(BorderFactory.createRaisedBevelBorder());
        frame.add(menu, BorderLayout.WEST);
    }

    public JButton getColorButton() {
        return colorButton;
    }

    public JButton getSizeButton() {
        return sizeButton;
    }

    public JSlider getSizeSlider() {
        return sizeSlider;
    }

    public JButton getHousesButton() {
        return housesButton;
    }

    public JButton getTreesButton() {
        return treesButton;
    }

    public JButton getVillageButton() {
        return villageButton;
    }
    
    public JButton getExitButton() {
    	return exitButton;
    }

	public JButton getBackgroundButton() {
		return backgroundButton;
	}
}
