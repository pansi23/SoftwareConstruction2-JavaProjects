package drawingTool;

import java.awt.Color;

public class Eye extends BodyParts {
	public Eye(int x, int y) {
		super(x, y, 10, 10, Color.black);
	}

	public void drawAt(int left, int bottom) {
		
		Drawing.pen().setColor(Color.black);
		Drawing.pen().fillOval(left+2*width , bottom+height, width, height);
	}
	@Override
    public void draw() {
    	drawAt(address.x, address.y);
    }


}
