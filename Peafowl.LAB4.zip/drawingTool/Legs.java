package drawingTool;

import java.awt.Color;

public class Legs extends BodyParts {
	public Legs(int x, int y) {
		super(x, y, 15, 50, Color.gray);
	}
	
	public void drawAt(int left, int bottom) {
        Drawing.pen().setColor(color);
        Drawing.pen().drawLine(left, bottom, left, bottom+height); //left leg
        Drawing.pen().drawLine(left+width, bottom, left+width, bottom+height);
    }

	@Override
    public void draw() {
        drawAt(address.x, address.y);
    }

}
