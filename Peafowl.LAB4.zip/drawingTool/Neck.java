package drawingTool;

import java.awt.Color;

public class Neck extends BodyParts{
	public Neck(int x, int y) {
		super(x, y, 20, 100, Color.blue);
	}
	
	public void drawAt(int left, int bottom) {
		Drawing.pen().setColor(Color.blue);
		Drawing.pen().fillRect(left , bottom, width, height);
	}
	@Override
    public void draw() {
        drawAt(address.x, address.y);
    }

}
