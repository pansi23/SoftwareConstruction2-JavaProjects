package drawingTool;

import java.awt.Color;

public class Feathers extends BodyParts {
	public Feathers(int x, int y) {
		super(x, y, 100, 70, Color.gray);
	}
	
	public void drawAt(int left, int bottom) {
        Drawing.pen().setColor(color);
        Drawing.pen().setColor(Color.GRAY);
        int[] xPoints = {left, left + width, left };
        int[] yPoints = {bottom, bottom + height/2, bottom+height};
        int nPoints = 3;
        Drawing.pen().fillPolygon(xPoints, yPoints, nPoints);
        
    }

    @Override
    public void draw() {
        drawAt(address.x, address.y);
    }

	
}
