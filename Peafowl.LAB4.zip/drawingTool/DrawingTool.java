package drawingTool;

import javax.swing.JFrame;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.awt.Color;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

@SuppressWarnings("serial")
public class DrawingTool extends JFrame implements ActionListener, ChangeListener {
    private DrawingArea drawing;
    private Buttons buttons = new Buttons();
    private List<Color> colorCycle = Arrays.asList(Color.blue, Color.green, Color.red, Color.yellow, Color.magenta);
    private int currentColorIndex = 0;

    public DrawingTool(String title) {
        super(title);
        
        setLayout(new BorderLayout());

        constructButtonMenu();
        constructDrawingArea();

        Dimension screenSize = getToolkit().getScreenSize();
        setBounds(0, 0, screenSize.width, screenSize.height);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        setVisible(true);
    }
    
    private void constructButtonMenu() {
        buttons.addButtonsToAPanel(this);
        buttons.addActionListener(this);
        buttons.addChangeListener(this);
    }

    private void constructDrawingArea() {
        drawing = new DrawingArea();
        add(drawing, BorderLayout.CENTER);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == buttons.getColorButton()) {
            changeColors();
        } else if (e.getSource() == buttons.getSizeButton()) {
            changeSizesRandomly();
        } else if (e.getSource() == buttons.getHousesButton()) {
            drawing.getScene().setHouses();
        } else if (e.getSource() == buttons.getTreesButton()) {
            drawing.getScene().setTrees();
        } else if (e.getSource() == buttons.getVillageButton()) {
            drawing.getScene().setVillageState();
        } else if (e.getSource() == buttons.getExitButton()) {
            dispose();
        }else if (e.getSource() == buttons.getBackgroundButton()) {
            drawing.getScene().changeBackground(this, drawing);
        }
        
        
    //    drawing.repaint();
        tidyUpDrawingArea();
        
    }

    @Override
    public void stateChanged(ChangeEvent e) {
        if (e.getSource() == buttons.getSizeSlider()) {
            updateSize();
            drawing.repaint();
        }
    }

    private void changeColors() {
        currentColorIndex = (currentColorIndex + 1) % colorCycle.size();
        drawing.getScene().setColor(colorCycle.get(currentColorIndex));
    }

    private void changeSizesRandomly() {
        int width = RandomNumber.getRandomNumber(50, 200);
        int height = RandomNumber.getRandomNumber(100, 400);
        drawing.getScene().setSize(width, height);
    }

    private void updateSize() {
        int size = buttons.getSizeSlider().getValue();
        drawing.getScene().setSize(size, 2 * size);
    }
    
    
	public void changeBackground() {
		getContentPane().setBackground(randomColor());
		drawing.setOpaque(false);
		revalidate();
		repaint();
	}

	private Color randomColor() {
		Random rand = new Random();

        // Generate random primary colors
        float r = rand.nextFloat();
        float g = rand.nextFloat();
        float b = rand.nextFloat();

        // Create the random color
        Color randomColor = new Color(r, g, b);
        
        return randomColor;
	}
	
	private void tidyUpDrawingArea() {
		drawing.removeAll();
		drawing.revalidate();
		drawing.repaint();		
	}
}
